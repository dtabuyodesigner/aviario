/**
 * Database Service (API Client)
 * Connects to Python/Flask Backend
 */

class DatabaseService {
    constructor() {
        this.baseUrl = '/api';
    }

    async init() {
        console.log("API Service ready.");
        // No local initialization needed for API mode
    }

    async getAll(table) {
        if (table === 'birds') table = 'birds'; // Endpoint is /api/birds

        try {
            const response = await fetch(`${this.baseUrl}/${table}`);
            if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
            return await response.json();
        } catch (e) {
            console.error("API Error fetching " + table, e);
            return [];
        }
    }

    async add(table, data) {
        if (table === 'pajaros' || table === 'birds') table = 'birds';

        try {
            const response = await fetch(`${this.baseUrl}/${table}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            });

            if (!response.ok) {
                const errData = await response.json();
                throw new Error(errData.error || 'API Error');
            }

            return await response.json();
        } catch (e) {
            console.error("API Error adding to " + table, e);
            throw e;
        }
    }

    async update(table, id, data) {
        if (table === 'pajaros' || table === 'birds') table = 'birds';
        try {
            const response = await fetch(`${this.baseUrl}/${table}/${id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });

            if (!response.ok) {
                const errData = await response.json();
                throw new Error(errData.error || 'API Error');
            }
            return await response.json();
        } catch (e) {
            console.error("API Error updating " + table, e);
            throw e;
        }
    }

    async delete(table, id) {
        if (table === 'pajaros' || table === 'birds') table = 'birds';
        try {
            const response = await fetch(`${this.baseUrl}/${table}/${id}`, {
                method: 'DELETE'
            });

            if (!response.ok) {
                const errData = await response.json();
                throw new Error(errData.error || 'API Error');
            }
            return await response.json();
        } catch (e) {
            console.error("API Error deleting " + table, e);
            throw e;
        }
    }


    async getVarieties(speciesUuid) {
        try {
            const url = speciesUuid ? `${this.baseUrl}/variedades?species_uuid=${speciesUuid}` : `${this.baseUrl}/variedades`;
            const response = await fetch(url);
            if (!response.ok) return [];
            return await response.json();
        } catch (e) {
            console.error("Error fetching varieties", e);
            return [];
        }
    }

    async getMutations(species, variety_uuid) {
        try {
            let url = `${this.baseUrl}/mutations`;
            if (variety_uuid) {
                url += `?variety_uuid=${variety_uuid}`;
            } else if (species) {
                url += `?species=${encodeURIComponent(species)}`;
            }
            const response = await fetch(url);
            if (!response.ok) return [];
            return await response.json();
        } catch (e) {
            console.error("Error fetching mutations", e);
            return [];
        }
    }

    async getBreeds(variety_uuid) {
        try {
            const url = variety_uuid ? `${this.baseUrl}/canary_breeds?variety_uuid=${variety_uuid}` : `${this.baseUrl}/canary_breeds`;
            const response = await fetch(url);
            if (!response.ok) return [];
            return await response.json();
        } catch (e) {
            console.error("Error fetching breeds", e);
            return [];
        }
    }

    // Stub for now
    async exportDatabase() {
        alert("La exportación ahora se realiza copiando el archivo 'aviario.db'");
        return {};
    }
}

export const db = new DatabaseService();
